#!/usr/bin/env perl

sleep 15;

print "Fail\n";
print "100\n";
print "This test always fails.\n";

